@extends ('main')

@section('title', '| About')
@section('content')
    

    <div class="row">
        <div class="col-md-12">
             <h1>About Me</h1>
             <p>Nothing really about me</p>
        </div>
    </div>
@endsection    