<!--Content to serve-->
<?php $__env->startSection('killer'); ?>
<div class="jumbotron">
    Welcome to the simplest but most effecient task app that will blow you mind away
    <br>
    <button class="btn btn-succes"><a href="<?php echo e(route('add_task.create')); ?>">Add New Task!</a></button>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>