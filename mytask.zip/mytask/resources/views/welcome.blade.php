@extends('layouts.parent')
<!--Content to serve-->
@section('killer')
<div class="jumbotron">
	<h1>
    This is my Task App
    </h1>
    <br>
    This is a scheduling application 
    <br>
    <br>
    <button class="btn btn-succes"><a href="{{route('add_task.create')}}">Add New Task!</a></button>
</div>


@endsection