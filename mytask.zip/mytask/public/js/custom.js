// $('.alert').hide(5000);

$('.alert').addClass('animated zoomInDown');

setTimeout(function(){$('.alert').addClass('animated hinge');},2000)
setTimeout(function(){$('.alert').removeClass('animated adeOutRight');},3000)

